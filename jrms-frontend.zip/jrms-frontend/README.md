# Hire Board — React Frontend

React frontend for the Job Recruitment Management System. Talks to your
Core Java + JDBC backend over a REST API.

## Setup

```bash
npm install
npm run dev
```

Runs on `http://localhost:5173`. All `/api/*` calls are proxied to
`http://localhost:8080` in development (see `vite.config.js`). Change the
proxy target if your Java backend runs on a different port.

For production, set `VITE_API_BASE_URL` in a `.env` file to your deployed
backend's URL, e.g.:

```
VITE_API_BASE_URL=https://your-backend.example.com/api
```

## Backend API contract expected by this frontend

Your Java backend (plain HTTP server, Servlets, or a framework like Spark)
needs to expose these JSON endpoints. Field names below match what the
React components read directly — keep your JDBC row-mapping consistent
with these, or adjust the frontend's field references to match yours.

### Auth
- `POST /api/auth/login` — body `{ email, password }`
  → `{ token: string, user: { name, email } }`

### Jobs
- `GET /api/jobs` → `[{ id, title, department, location, salary, status, description }]`
- `POST /api/jobs` — same shape minus `id`
- `PUT /api/jobs/{id}` — same shape
- `DELETE /api/jobs/{id}`
  - `status` is `"Open"` or `"Closed"`

### Candidates
- `GET /api/candidates` → `[{ id, name, email, phone, skills, experienceYears }]`
- `POST /api/candidates` — same shape minus `id`
- `PUT /api/candidates/{id}` — same shape
- `DELETE /api/candidates/{id}`

### Applications
- `GET /api/applications` →
  `[{ id, jobId, candidateId, jobTitle, candidateName, status }]`
  (`jobTitle` / `candidateName` are denormalized via a JOIN so the UI
  doesn't need extra lookups — do this in your JDBC query)
- `POST /api/applications` — body `{ jobId, candidateId, status }`
- `PUT /api/applications/{id}/status` — body `{ status }`
- `DELETE /api/applications/{id}`
  - `status` is one of: `Applied`, `Screening`, `Interview`, `Offer`, `Hired`, `Rejected`

## Auth token handling

The frontend stores the login token in `localStorage` under `jrms_token`
and sends it as `Authorization: Bearer <token>` on every request. Your
backend can validate this however you like (e.g. a simple signed token
or a session lookup in your `users` table via JDBC).

## Suggested database tables

```sql
CREATE TABLE jobs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  department VARCHAR(100),
  location VARCHAR(100),
  salary VARCHAR(50),
  status VARCHAR(20) DEFAULT 'Open',
  description TEXT
);

CREATE TABLE candidates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30),
  skills VARCHAR(255),
  experience_years INT
);

CREATE TABLE applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  job_id INT REFERENCES jobs(id),
  candidate_id INT REFERENCES candidates(id),
  status VARCHAR(20) DEFAULT 'Applied',
  applied_date DATE DEFAULT CURRENT_DATE
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL
);
```

## Project structure

```
src/
  api/client.js       — all fetch calls to the Java backend
  components/         — Sidebar, StatusBadge, Modal
  pages/               — Login, Dashboard, Jobs, Candidates, Applications
  App.jsx              — routing + auth guard
```
