/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#171B26',
        navy: '#12151F',
        navyLight: '#1D2331',
        paper: '#F3F4F1',
        paperDeep: '#E9EAE5',
        line: '#DBDDD6',
        teal: '#1F6F5C',
        tealDeep: '#164F42',
        amber: '#B8862F',
        rose: '#A6432F',
        slateInk: '#4B5160'
      },
      fontFamily: {
        serif: ['"Source Serif 4"', 'Georgia', 'serif'],
        sans: ['"IBM Plex Sans"', 'system-ui', 'sans-serif']
      },
      borderRadius: {
        sm: '3px',
        DEFAULT: '4px',
        md: '6px'
      }
    }
  },
  plugins: []
};
