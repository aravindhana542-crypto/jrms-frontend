// Central place that knows how to reach the Java backend.
// In dev, Vite proxies "/api" to http://localhost:8080 (see vite.config.js).
// In production, set VITE_API_BASE_URL to your deployed backend's origin.

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

async function request(path, options = {}) {
  const token = localStorage.getItem('jrms_token');

  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers
    }
  });

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      message = body.message || message;
    } catch {
      // response had no JSON body; keep default message
    }
    throw new Error(message);
  }

  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  get: (path) => request(path),
  post: (path, data) => request(path, { method: 'POST', body: JSON.stringify(data) }),
  put: (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data) }),
  del: (path) => request(path, { method: 'DELETE' })
};

// --- Resource-specific helpers -------------------------------------------
// These map 1:1 to the endpoints your Java servlets/handlers should expose.

export const jobsApi = {
  list: () => api.get('/jobs'),
  get: (id) => api.get(`/jobs/${id}`),
  create: (job) => api.post('/jobs', job),
  update: (id, job) => api.put(`/jobs/${id}`, job),
  remove: (id) => api.del(`/jobs/${id}`)
};

export const candidatesApi = {
  list: () => api.get('/candidates'),
  get: (id) => api.get(`/candidates/${id}`),
  create: (candidate) => api.post('/candidates', candidate),
  update: (id, candidate) => api.put(`/candidates/${id}`, candidate),
  remove: (id) => api.del(`/candidates/${id}`)
};

export const applicationsApi = {
  list: () => api.get('/applications'),
  create: (application) => api.post('/applications', application),
  updateStatus: (id, status) => api.put(`/applications/${id}/status`, { status }),
  remove: (id) => api.del(`/applications/${id}`)
};

export const authApi = {
  login: (email, password) => api.post('/auth/login', { email, password })
};
