const STYLES = {
  Open: 'border-teal text-tealDeep bg-teal/10',
  Closed: 'border-slateInk text-slateInk bg-slateInk/10',
  Applied: 'border-slateInk text-slateInk bg-slateInk/10',
  Screening: 'border-amber text-amber bg-amber/10',
  Interview: 'border-amber text-amber bg-amber/10',
  Offer: 'border-teal text-tealDeep bg-teal/10',
  Hired: 'border-teal text-tealDeep bg-teal/15',
  Rejected: 'border-rose text-rose bg-rose/10'
};

export default function StatusBadge({ status }) {
  const style = STYLES[status] || 'border-line text-slateInk bg-white';
  return (
    <span className={`inline-block px-2.5 py-0.5 text-xs rounded-full border ${style}`}>
      {status}
    </span>
  );
}
