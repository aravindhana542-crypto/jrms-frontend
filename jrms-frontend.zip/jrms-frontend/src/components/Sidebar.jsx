import { NavLink, useNavigate } from 'react-router-dom';

const links = [
  { to: '/', label: 'Overview', end: true },
  { to: '/jobs', label: 'Job postings' },
  { to: '/candidates', label: 'Candidates' },
  { to: '/applications', label: 'Pipeline' }
];

export default function Sidebar({ user, onLogout }) {
  const navigate = useNavigate();

  function handleLogout() {
    onLogout();
    navigate('/login');
  }

  return (
    <aside className="w-60 shrink-0 bg-navy text-paper flex flex-col h-screen sticky top-0">
      <div className="px-6 pt-7 pb-6">
        <span className="font-serif text-2xl tracking-tight">Hire Board</span>
        <p className="text-xs text-slateInk mt-1">Recruitment management</p>
      </div>

      <nav className="flex-1 px-3 space-y-1">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.end}
            className={({ isActive }) =>
              `block px-3 py-2 rounded text-sm transition-colors ${
                isActive
                  ? 'bg-teal text-white'
                  : 'text-paper/80 hover:bg-navyLight hover:text-white'
              }`
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>

      <div className="px-6 py-5 border-t border-white/10">
        <p className="text-sm text-paper/90">{user?.name || 'Recruiter'}</p>
        <p className="text-xs text-slateInk mb-3">{user?.email || ''}</p>
        <button
          onClick={handleLogout}
          className="text-xs text-paper/70 hover:text-white underline underline-offset-2"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
