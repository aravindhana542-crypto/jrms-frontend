export default function Modal({ title, onClose, children }) {
  return (
    <div
      className="fixed inset-0 bg-ink/50 flex items-center justify-center z-50 px-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-md border border-line w-full max-w-lg max-h-[85vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-line">
          <h2 className="font-serif text-lg">{title}</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="text-slateInk hover:text-ink text-xl leading-none"
          >
            ×
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
