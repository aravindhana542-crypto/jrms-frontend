import { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Jobs from './pages/Jobs';
import Candidates from './pages/Candidates';
import Applications from './pages/Applications';

export default function App() {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('jrms_user');
    return stored ? JSON.parse(stored) : null;
  });

  function handleLogin(userData) {
    localStorage.setItem('jrms_user', JSON.stringify(userData));
    setUser(userData);
  }

  function handleLogout() {
    localStorage.removeItem('jrms_token');
    localStorage.removeItem('jrms_user');
    setUser(null);
  }

  if (!user) {
    return (
      <Routes>
        <Route path="*" element={<Login onLogin={handleLogin} />} />
      </Routes>
    );
  }

  return (
    <div className="flex">
      <Sidebar user={user} onLogout={handleLogout} />
      <main className="flex-1 min-h-screen">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/candidates" element={<Candidates />} />
          <Route path="/applications" element={<Applications />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
