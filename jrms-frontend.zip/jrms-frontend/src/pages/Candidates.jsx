import { useEffect, useState } from 'react';
import { candidatesApi } from '../api/client';
import Modal from '../components/Modal';

const EMPTY_CANDIDATE = {
  name: '',
  email: '',
  phone: '',
  skills: '',
  experienceYears: ''
};

export default function Candidates() {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);

  function load() {
    setLoading(true);
    candidatesApi
      .list()
      .then(setCandidates)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  const filtered = candidates.filter((c) =>
    `${c.name} ${c.email} ${c.skills}`.toLowerCase().includes(query.toLowerCase())
  );

  function openCreate() {
    setEditing({ ...EMPTY_CANDIDATE });
    setShowForm(true);
  }

  function openEdit(candidate) {
    setEditing({ ...candidate });
    setShowForm(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    try {
      if (editing.id) {
        await candidatesApi.update(editing.id, editing);
      } else {
        await candidatesApi.create(editing);
      }
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete(id) {
    if (!confirm('Remove this candidate?')) return;
    try {
      await candidatesApi.remove(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="p-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl mb-1">Candidates</h1>
          <p className="text-slateInk">Everyone in your talent pool.</p>
        </div>
        <button
          onClick={openCreate}
          className="bg-teal hover:bg-tealDeep text-white text-sm font-medium px-4 py-2 rounded transition-colors"
        >
          Add candidate
        </button>
      </div>

      <input
        type="text"
        placeholder="Search by name, email, or skill"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="input max-w-sm mb-5"
      />

      {error && <p className="text-rose mb-4">{error}</p>}

      <div className="border border-line rounded-md bg-white overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slateInk border-b border-line">
              <th className="px-5 py-3 font-medium">Name</th>
              <th className="px-5 py-3 font-medium">Contact</th>
              <th className="px-5 py-3 font-medium">Skills</th>
              <th className="px-5 py-3 font-medium">Experience</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={5} className="px-5 py-6 text-slateInk">
                  Loading candidates…
                </td>
              </tr>
            )}
            {!loading && filtered.length === 0 && (
              <tr>
                <td colSpan={5} className="px-5 py-6 text-slateInk">
                  No candidates match yet.
                </td>
              </tr>
            )}
            {filtered.map((c) => (
              <tr key={c.id} className="border-b border-line last:border-0">
                <td className="px-5 py-3">{c.name}</td>
                <td className="px-5 py-3 text-slateInk">
                  <div>{c.email}</div>
                  <div className="text-xs">{c.phone}</div>
                </td>
                <td className="px-5 py-3 text-slateInk">{c.skills}</td>
                <td className="px-5 py-3 text-slateInk">{c.experienceYears} yrs</td>
                <td className="px-5 py-3 text-right space-x-3">
                  <button
                    onClick={() => openEdit(c)}
                    className="text-teal hover:text-tealDeep text-sm"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(c.id)}
                    className="text-rose hover:text-rose/80 text-sm"
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title={editing.id ? 'Edit candidate' : 'Add candidate'} onClose={() => setShowForm(false)}>
          <form onSubmit={handleSave} className="space-y-4">
            <Field label="Full name">
              <input
                required
                value={editing.name}
                onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                className="input"
              />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Email">
                <input
                  type="email"
                  required
                  value={editing.email}
                  onChange={(e) => setEditing({ ...editing, email: e.target.value })}
                  className="input"
                />
              </Field>
              <Field label="Phone">
                <input
                  value={editing.phone}
                  onChange={(e) => setEditing({ ...editing, phone: e.target.value })}
                  className="input"
                />
              </Field>
            </div>
            <Field label="Skills (comma separated)">
              <input
                value={editing.skills}
                onChange={(e) => setEditing({ ...editing, skills: e.target.value })}
                className="input"
                placeholder="Java, SQL, Spring"
              />
            </Field>
            <Field label="Years of experience">
              <input
                type="number"
                min="0"
                value={editing.experienceYears}
                onChange={(e) => setEditing({ ...editing, experienceYears: e.target.value })}
                className="input"
              />
            </Field>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="text-sm text-slateInk px-4 py-2"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-teal hover:bg-tealDeep text-white text-sm font-medium px-4 py-2 rounded"
              >
                Save candidate
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-sm text-slateInk mb-1">{label}</span>
      {children}
    </label>
  );
}
