import { useEffect, useState } from 'react';
import { jobsApi, applicationsApi } from '../api/client';

const STAGES = ['Applied', 'Screening', 'Interview', 'Offer', 'Hired'];

export default function Dashboard() {
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([jobsApi.list(), applicationsApi.list()])
      .then(([jobsData, appsData]) => {
        setJobs(jobsData);
        setApplications(appsData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const openRoles = jobs.filter((j) => j.status === 'Open').length;
  const stageCounts = STAGES.map(
    (stage) => applications.filter((a) => a.status === stage).length
  );
  const maxCount = Math.max(...stageCounts, 1);

  return (
    <div className="p-10 max-w-5xl">
      <h1 className="font-serif text-3xl mb-1">Good to see you</h1>
      <p className="text-slateInk mb-10">
        Here is where every open role and candidate stands today.
      </p>

      {error && <p className="text-rose mb-6">{error}</p>}

      <div className="grid grid-cols-3 gap-4 mb-10">
        <div className="border border-line rounded-md bg-white p-5">
          <p className="text-3xl font-serif">{loading ? '—' : openRoles}</p>
          <p className="text-sm text-slateInk mt-1">Open roles</p>
        </div>
        <div className="border border-line rounded-md bg-white p-5">
          <p className="text-3xl font-serif">{loading ? '—' : applications.length}</p>
          <p className="text-sm text-slateInk mt-1">Active applications</p>
        </div>
        <div className="border border-line rounded-md bg-white p-5">
          <p className="text-3xl font-serif">
            {loading ? '—' : applications.filter((a) => a.status === 'Hired').length}
          </p>
          <p className="text-sm text-slateInk mt-1">Hired this cycle</p>
        </div>
      </div>

      <div className="border border-line rounded-md bg-white p-6">
        <h2 className="font-serif text-lg mb-5">Candidate pipeline</h2>
        <div className="space-y-3">
          {STAGES.map((stage, i) => (
            <div key={stage} className="flex items-center gap-4">
              <span className="w-24 text-sm text-slateInk shrink-0">{stage}</span>
              <div className="flex-1 bg-paperDeep rounded h-6 overflow-hidden">
                <div
                  className="h-full bg-teal rounded"
                  style={{ width: `${(stageCounts[i] / maxCount) * 100}%` }}
                />
              </div>
              <span className="w-6 text-sm text-right">{stageCounts[i]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
