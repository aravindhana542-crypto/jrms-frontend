import { useEffect, useState } from 'react';
import { jobsApi } from '../api/client';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';

const EMPTY_JOB = {
  title: '',
  department: '',
  location: '',
  salary: '',
  status: 'Open',
  description: ''
};

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editing, setEditing] = useState(null); // job object or null
  const [showForm, setShowForm] = useState(false);

  function load() {
    setLoading(true);
    jobsApi
      .list()
      .then(setJobs)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  function openCreate() {
    setEditing({ ...EMPTY_JOB });
    setShowForm(true);
  }

  function openEdit(job) {
    setEditing({ ...job });
    setShowForm(true);
  }

  async function handleSave(e) {
    e.preventDefault();
    try {
      if (editing.id) {
        await jobsApi.update(editing.id, editing);
      } else {
        await jobsApi.create(editing);
      }
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete(id) {
    if (!confirm('Remove this job posting?')) return;
    try {
      await jobsApi.remove(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="p-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl mb-1">Job postings</h1>
          <p className="text-slateInk">Roles open for hire and their status.</p>
        </div>
        <button
          onClick={openCreate}
          className="bg-teal hover:bg-tealDeep text-white text-sm font-medium px-4 py-2 rounded transition-colors"
        >
          New job posting
        </button>
      </div>

      {error && <p className="text-rose mb-4">{error}</p>}

      <div className="border border-line rounded-md bg-white overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slateInk border-b border-line">
              <th className="px-5 py-3 font-medium">Title</th>
              <th className="px-5 py-3 font-medium">Department</th>
              <th className="px-5 py-3 font-medium">Location</th>
              <th className="px-5 py-3 font-medium">Salary</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={6} className="px-5 py-6 text-slateInk">
                  Loading job postings…
                </td>
              </tr>
            )}
            {!loading && jobs.length === 0 && (
              <tr>
                <td colSpan={6} className="px-5 py-6 text-slateInk">
                  No roles posted yet. Create one to start receiving applications.
                </td>
              </tr>
            )}
            {jobs.map((job) => (
              <tr key={job.id} className="border-b border-line last:border-0">
                <td className="px-5 py-3">{job.title}</td>
                <td className="px-5 py-3 text-slateInk">{job.department}</td>
                <td className="px-5 py-3 text-slateInk">{job.location}</td>
                <td className="px-5 py-3 text-slateInk">{job.salary}</td>
                <td className="px-5 py-3">
                  <StatusBadge status={job.status} />
                </td>
                <td className="px-5 py-3 text-right space-x-3">
                  <button
                    onClick={() => openEdit(job)}
                    className="text-teal hover:text-tealDeep text-sm"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(job.id)}
                    className="text-rose hover:text-rose/80 text-sm"
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title={editing.id ? 'Edit job posting' : 'New job posting'} onClose={() => setShowForm(false)}>
          <form onSubmit={handleSave} className="space-y-4">
            <Field label="Title">
              <input
                required
                value={editing.title}
                onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                className="input"
              />
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Department">
                <input
                  value={editing.department}
                  onChange={(e) => setEditing({ ...editing, department: e.target.value })}
                  className="input"
                />
              </Field>
              <Field label="Location">
                <input
                  value={editing.location}
                  onChange={(e) => setEditing({ ...editing, location: e.target.value })}
                  className="input"
                />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="Salary">
                <input
                  value={editing.salary}
                  onChange={(e) => setEditing({ ...editing, salary: e.target.value })}
                  className="input"
                  placeholder="e.g. 8–12 LPA"
                />
              </Field>
              <Field label="Status">
                <select
                  value={editing.status}
                  onChange={(e) => setEditing({ ...editing, status: e.target.value })}
                  className="input"
                >
                  <option>Open</option>
                  <option>Closed</option>
                </select>
              </Field>
            </div>
            <Field label="Description">
              <textarea
                rows={4}
                value={editing.description}
                onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                className="input"
              />
            </Field>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="text-sm text-slateInk px-4 py-2"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-teal hover:bg-tealDeep text-white text-sm font-medium px-4 py-2 rounded"
              >
                Save job posting
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-sm text-slateInk mb-1">{label}</span>
      {children}
    </label>
  );
}
