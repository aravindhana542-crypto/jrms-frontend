import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../api/client';

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const result = await authApi.login(email, password);
      localStorage.setItem('jrms_token', result.token);
      onLogin(result.user);
      navigate('/');
    } catch (err) {
      setError(err.message || 'Could not sign in. Check your credentials.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-navy flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <span className="font-serif text-3xl text-paper">Hire Board</span>
          <p className="text-slateInk text-sm mt-1">Recruitment management</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-paper rounded-md border border-line p-6 space-y-4">
          <div>
            <label className="block text-sm text-slateInk mb-1" htmlFor="email">
              Work email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border border-line rounded px-3 py-2 text-sm bg-white focus:border-teal"
              placeholder="you@company.com"
            />
          </div>

          <div>
            <label className="block text-sm text-slateInk mb-1" htmlFor="password">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border border-line rounded px-3 py-2 text-sm bg-white focus:border-teal"
              placeholder="••••••••"
            />
          </div>

          {error && <p className="text-sm text-rose">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-teal hover:bg-tealDeep text-white text-sm font-medium py-2.5 rounded transition-colors disabled:opacity-60"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
      </div>
    </div>
  );
}
