import { useEffect, useState } from 'react';
import { applicationsApi, jobsApi, candidatesApi } from '../api/client';
import Modal from '../components/Modal';

const STAGES = ['Applied', 'Screening', 'Interview', 'Offer', 'Hired', 'Rejected'];

export default function Applications() {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [newApp, setNewApp] = useState({ jobId: '', candidateId: '' });

  function load() {
    setLoading(true);
    Promise.all([applicationsApi.list(), jobsApi.list(), candidatesApi.list()])
      .then(([apps, jobsData, candidatesData]) => {
        setApplications(apps);
        setJobs(jobsData);
        setCandidates(candidatesData);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function moveStage(app, nextStatus) {
    try {
      await applicationsApi.updateStatus(app.id, nextStatus);
      setApplications((prev) =>
        prev.map((a) => (a.id === app.id ? { ...a, status: nextStatus } : a))
      );
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleCreate(e) {
    e.preventDefault();
    try {
      await applicationsApi.create({ ...newApp, status: 'Applied' });
      setShowForm(false);
      setNewApp({ jobId: '', candidateId: '' });
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="p-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-serif text-3xl mb-1">Pipeline</h1>
          <p className="text-slateInk">Move each application forward as it progresses.</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-teal hover:bg-tealDeep text-white text-sm font-medium px-4 py-2 rounded transition-colors"
        >
          Log application
        </button>
      </div>

      {error && <p className="text-rose mb-4">{error}</p>}
      {loading && <p className="text-slateInk">Loading pipeline…</p>}

      {!loading && (
        <div className="grid grid-cols-6 gap-3 overflow-x-auto">
          {STAGES.map((stage) => (
            <div key={stage} className="min-w-[190px]">
              <p className="text-xs text-slateInk mb-2">
                {stage} · {applications.filter((a) => a.status === stage).length}
              </p>
              <div className="space-y-2">
                {applications
                  .filter((a) => a.status === stage)
                  .map((app) => (
                    <div
                      key={app.id}
                      className="border border-line bg-white rounded-md p-3 text-sm"
                    >
                      <p className="font-medium">{app.candidateName}</p>
                      <p className="text-xs text-slateInk mb-2">{app.jobTitle}</p>
                      <select
                        value={app.status}
                        onChange={(e) => moveStage(app, e.target.value)}
                        className="w-full text-xs border border-line rounded px-2 py-1 bg-paper focus:border-teal"
                      >
                        {STAGES.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <Modal title="Log a new application" onClose={() => setShowForm(false)}>
          <form onSubmit={handleCreate} className="space-y-4">
            <label className="block">
              <span className="block text-sm text-slateInk mb-1">Candidate</span>
              <select
                required
                value={newApp.candidateId}
                onChange={(e) => setNewApp({ ...newApp, candidateId: e.target.value })}
                className="input"
              >
                <option value="">Select a candidate</option>
                {candidates.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="block text-sm text-slateInk mb-1">Job posting</span>
              <select
                required
                value={newApp.jobId}
                onChange={(e) => setNewApp({ ...newApp, jobId: e.target.value })}
                className="input"
              >
                <option value="">Select a role</option>
                {jobs.map((j) => (
                  <option key={j.id} value={j.id}>
                    {j.title}
                  </option>
                ))}
              </select>
            </label>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="text-sm text-slateInk px-4 py-2"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-teal hover:bg-tealDeep text-white text-sm font-medium px-4 py-2 rounded"
              >
                Log application
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
